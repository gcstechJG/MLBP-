var util;
(function (util) {
  function toggleTOCVisibility(event, handleId, tocContainerId) {
    evemt = event || window.event;
  
    var tocContainer = document.getElementById(tocContainerId);
    var containerHandle = document.getElementById(handleId);
    
    if (event.ctrlKey || event.metaKey) {
    
        if (!containerHandle.hasOwnProperty("AllExpanded")) {
            containerHandle.AllExpanded = false;
        }
        
        var allExpanded = false;
        if (containerHandle.AllExpanded) {
            allExpanded = true;
        }
            
        var handleClassName = "TOCHandle TOCHandleExpanded";
        var displayValue = "block";
        
        if (allExpanded) {
            handleClassName = "TOCHandle TOCHandleCollapsed";
            displayValue = "none";
        } 
            
        var handles = tocContainer.querySelectorAll("span.TOCHandle");
        var i;       
        for (i = 0; i < handles.length; i++) {
            handles[i].className = handleClassName;
        }
        
        
        var lists = tocContainer.querySelectorAll("ul");
        for (i = 0; i < lists.length; i++) {
            lists[i].style.display = displayValue;
        }
        
        if (displayValue == "none") {
            var topList = tocContainer.querySelector("ul.TOCItems");
            topList.style.display = "block";        
        }
        
        containerHandle.AllExpanded = !allExpanded;
        
        tocContainer.style.display = displayValue;
        containerHandle.className = handleClassName;
        
    } else {

        if (tocContainer.style.display == "block") {
            tocContainer.style.display = "none";
            containerHandle.className = "TOCHandle TOCHandleCollapsed";
        } else {
            tocContainer.style.display = "block";
            containerHandle.className = "TOCHandle TOCHandleExpanded";
        }
    }
  }
  
  util.toggleTOCVisibility = toggleTOCVisibility;
  
    function autoNumber() {
    
            function alphabetize(n) {
                var ordA = 'A'.charCodeAt(0);
                var ordZ = 'Z'.charCodeAt(0);
                var len = ordZ - ordA + 1;
      
                var s = "";
                while(n >= 0) {
                    s = String.fromCharCode(n % len + ordA-1) + s;
                    n = Math.floor(n / len) - 1;
                }
                return s;
            }
    
            function romanize (num) {
            if (!+num)
            return false;
            var	digits = String(+num).split(""),
            key = ["","C","CC","CCC","CD","D","DC","DCC","DCCC","CM",
		       "","X","XX","XXX","XL","L","LX","LXX","LXXX","XC",
		       "","I","II","III","IV","V","VI","VII","VIII","IX"],
            roman = "",
            i = 3;
            while (i--)
            roman = (key[+digits.pop() + (i * 10)] || "") + roman;
            return Array(+digits.join("") + 1).join("M") + roman;
        }
        
        function formatNumber(number, format) {
            var formattedNumber =  "";
            switch (format) {
                case "n":
                case "N":
                    formattedNumber = number.toString();
                break;
                case "a":
                    formattedNumber = alphabetize(number).toLowerCase();
                    break;
                case "A":
                    formattedNumber = alphabetize(number);
                    break;
                case "i":
                    formattedNumber = romanize(number).toLowerCase();
                break;
                case "I":
                    formattedNumber = romanize(number);
                break;
                default:
                    formattedNumber = number.toString();
            }
            return formattedNumber;
        }
        
    var nodes = document.querySelectorAll("h1, h2, h3, h4, h5, h6, autonumber");
    var h1Counter = 0;
    var h2Counter = 0;
    var h3Counter = 0;
    var h4Counter = 0;
    var h5Counter = 0;
    var h6Counter = 0;
    for (var i = 0; i < nodes.length; i++) {
        node = nodes[i];
        switch (node.nodeName.toLowerCase()) {
            case "h1":
                h1Counter = h1Counter + 1;
                h2Counter = 0;
                break;
            case "h2":
                h2Counter = h2Counter + 1;
                h3Counter = 0;
                break;
            case "h3":
                h3Counter = h3Counter + 1;
                h4Counter = 0;              
                break;
            case "h4":
                h4Counter = h4Counter + 1;
                h5Counter = 0;
                break;
            case "h5":
                h5Counter = h5Counter + 1;
                h6Counter = 0;
                break;
            case "h6":
                h6Counter = h6Counter + 1;
                break;
            case "autonumber":
                var counterName = node.getAttribute("stream-name");
                switch (counterName.toLowerCase()) {
                    case "h1":
                        number = h1Counter;
                        break;
                    case "h2":
                        number = h2Counter;
                        break;
                    case "h3":
                        number = h3Counter;             
                        break;
                    case "h4":
                        number = h4Counter;
                        break;
                    case "h5":
                        number = h5Counter;
                        break;
                    case "h6":
                        number = h6Counter;
                        break;
                }
                var format = node.getAttribute("format");
                format = format ? format : "n";
                node.innerHTML = formatNumber(number, format);
                break
            default:
                number = "";
        }
        
        
    } 
  }
  
  util.autoNumber = autoNumber;
  
  
})(util || (util = {}))